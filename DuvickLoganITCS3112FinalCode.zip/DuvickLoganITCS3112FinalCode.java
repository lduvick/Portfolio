import java.util.Scanner;
import java.io.*;
import java.util.Random;

public class DuvickLoganITCS3112FinalCode{
    public static void main(String[] args) {
        int plHealth=100;
        int plDmg=0;
        int plAttack=0;
        int healPotion=40;
        int numPotions=3;
        boolean takenPotion=false;
        int monOneHealth=20;
        int monTwoHealth=20;
        int monThreeHealth=50;
        int monAttack=0;
        int monDamage=0;
        String userChoice =" ";
        Boolean monOne=true;
        Boolean monTwo=true;
        Boolean monThree=true;
        Scanner input=new Scanner(System.in);
        Random random=new Random();

        System.out.println("Welcome to the game of Dungeons and Dragons!");
        System.out.println("This is designed to be a very short demo of how the real game works, all chance and no predictability.");
        System.out.println("To begin the game, please type fight now.");

        userChoice=input.nextLine().toLowerCase();
        //while(userChoice.toLowerCase()!="fight"){
            //System.out.println("first check");
            if(userChoice.toLowerCase()!="fight"){
                System.out.println("Incorrect word detected, try again.");
                userChoice=input.nextLine();
            }
        //}
        System.out.println("Greetings mighty barbarian! You have been summoned to the town of Carthan to slay the beasts that threaten this town!");
        System.out.println("You have been promised a large amount of gold as your reward for slaying the beasts.");
        System.out.println("Asking around to the townfolk about these beasts and they tell you that one of the beasts is in the forest surrounding the town.");
        System.out.println("You soon find the beast and it is a large dire wolf which you then attack and that is where you now begin!");
        while(monOne){
            System.out.println("Your Health: "+plHealth);
            System.out.println("What do you wish to do?(Fight,Heal,Dodge,Flee)");
            userChoice=input.nextLine().toLowerCase();
            if(userChoice.toLowerCase().equals("fight")){
                plAttack=random.nextInt(20)+4;
                if(plAttack==23){
                    System.out.println("Natural 20! Critical Hit!");
                    plDmg=random.nextInt(12)+1+random.nextInt(12)+1;
                    monOneHealth=monOneHealth-plDmg;
                    System.out.println("The dire wolf takes "+plDmg+" damage from your attack");
                }else if(plAttack<23&&plAttack>=13){
                    System.out.println("You hit the dire wolf with your axe!");
                    plDmg=random.nextInt(12)+1;
                    monOneHealth=monOneHealth-plDmg;
                    System.out.println("The dire wolf takes "+plDmg+" damage from your attack");
                }else{
                    System.out.println("You swing wildly and miss the direwolf.");
                }
                System.out.println("The dire wolf now attacks you");
                monAttack=random.nextInt(20)+1;
                if(monAttack==20){
                    System.out.println("The wolf bites you at a critical area!");
                    monDamage=random.nextInt(6)+1+random.nextInt(6)+1;
                    System.out.println("You take "+monDamage+" points of damage.");
                    plHealth=plHealth-monDamage;
                }else if(monAttack<20&&monAttack>=15){
                    System.out.println("The wolf manages to bite you.");
                    monDamage=random.nextInt(6)+1;
                    System.out.println("You take "+monDamage+" points of damage.");
                    plHealth=plHealth-monDamage;
                }else{
                    System.out.println("The wolf attempts to bite you and you deflect it with your axe");
                }
            }else if(userChoice.toLowerCase().equals("heal")){
                if(takenPotion){
                    System.out.println("You already drank all of your health potions!");
                }else{
                    if(plHealth==100){
                        System.out.println("You are at maximum health so a health potion will not help you.");
                    }else if(plHealth<100&&plHealth>=60){
                        System.out.println("You drink your health potion and feel back to normal");
                        plHealth=100;
                        numPotions--;
                        if(numPotions==0){
                            takenPotion=true;
                        }
                    }else{
                        System.out.println("You drink a health potion and feel better, you have gained 40 health points back");
                        plHealth+=healPotion;
                        numPotions--;
                        if(numPotions==0){
                            takenPotion=true;
                        }
                    }
                }
            }else if(userChoice.toLowerCase().equals("dodge")){
                System.out.println("You dodge the wolf's attack!");
            }else if(userChoice.toLowerCase().equals("flee")){
                System.out.println("....really? Fine, you run away from the wolf as the town laughs at you!");
            }else{
                System.out.println("Please give a valid input");
                userChoice=input.next();
            }
            if(monOneHealth<=0){
                System.out.println("You successfully kill the dire wolf!");
                monOne=false;
            }
            if(plHealth<=0){
                System.out.println("You were killed by the dire wolf...really unlucky I guess?");
                break;
            }

        }
        System.out.println("After managing to successfully kill the dire wolf, you brought back it's corpse to the town and rested for a while");
        if(plHealth==100){
            System.out.println("Since you were not damaged in that fight or had healed up you managed to rest easy.");
        }else if(plHealth<100&& plHealth>=50){
            System.out.println("During your rest you heal up back to normal and are ready to get out and hunt again");
            plHealth=100;
        }else{
            plHealth+=50;
            System.out.println("You were badly hurt, and resting allowed you to heal up, try to be more careful this time!");
        }
        System.out.println("After resting you went back into the forest and searched for the second monster, after hours of searching it got dark.");
        System.out.println("You kept searching in the dark until you heard a screech from above, you look up in time to see a dark bird-like shape soaring towards you with it's claws aimed at your head.");
        System.out.println("Time to fight again!");
        while(monTwo){
            System.out.println("Your Health: "+plHealth);
            System.out.println("What do you wish to do?(Fight,Heal,Dodge,Flee)");
            userChoice=input.nextLine().toLowerCase();
            if(userChoice.toLowerCase().equals("fight")){
                plAttack=random.nextInt(20)+4;
                if(plAttack==23){
                    System.out.println("Natural 20! Critical Hit!");
                    plDmg=random.nextInt(12)+1+random.nextInt(12)+1;
                   monTwoHealth-=plDmg;
                    System.out.println("The giant hawk takes "+plDmg+" damage from your attack");
                }else if(plAttack<23&&plAttack>=13){
                    System.out.println("You hit the giant hawk with your axe!");
                    plDmg=random.nextInt(12)+1;
                    monTwoHealth-=plDmg;
                    System.out.println("The giant hawk takes "+plDmg+" damage from your attack");
                }else{
                    System.out.println("You swing wildly and miss the giant hawk.");
                }
                System.out.println("The giant hawk now attacks you");
                monAttack=random.nextInt(20)+1;
                if(monAttack==20){
                    System.out.println("The hawk claws you at a critical area!");
                    monDamage=random.nextInt(8)+1+random.nextInt(8)+1;
                    System.out.println("You take "+monDamage+" points of damage.");
                    plHealth=plHealth-monDamage;
                }else if(monAttack<20&&monAttack>=15){
                    System.out.println("The hawk manages to claw you.");
                    monDamage=random.nextInt(8)+1;
                    System.out.println("You take "+monDamage+" points of damage.");
                    plHealth=plHealth-monDamage;
                }else{
                    System.out.println("The giant hawk attempts to claw you and you deflect it with your axe");
                }
            }else if(userChoice.toLowerCase().equals("heal")){
                if(takenPotion){
                    System.out.println("You already drank all of your health potions!");
                }else{
                    if(plHealth==100){
                        System.out.println("You are at maximum health so a health potion will not help you.");
                    }else if(plHealth<100&&plHealth>=60){
                        System.out.println("You drink your health potion and feel back to normal");
                        plHealth=100;
                        numPotions--;
                        if(numPotions==0){
                            takenPotion=true;
                        }
                    }else{
                        System.out.println("You drink a health potion and feel better, you have gained 40 health points back");
                        plHealth+=40;
                        numPotions--;
                        if(numPotions==0){
                            takenPotion=true;
                        }
                    }
                }
            }else if(userChoice.toLowerCase().equals("dodge")){
                System.out.println("You dodge the giant hawk's attack!");
            }else if(userChoice.toLowerCase().equals("flee")){
                System.out.println("You flee from the giant hawk, guess you aren't as strong as you thought");
            }else{
                System.out.println("Please give a valid input");
                userChoice=input.next();
            }
            if(monTwoHealth<=0){
                System.out.println("You successfully kill the giant hawk!");
                monTwo=false;
            }
            if(plHealth<=0){
                System.out.println("You were killed by the giant hawk...really unlucky I guess?");
                break;
            }

        }
        System.out.println("Once again, you were successful at killing another monster, this one a giant hawk!");
        System.out.println("You once again bring the corpse back to town as proof of your success and head to the inn to rest once more.");
        if(plHealth==100){
            System.out.println("Since you were not damaged in that fight or had healed up you managed to rest easy.");
        }else if(plHealth<100&& plHealth>=50){
            System.out.println("During your rest you heal up back to normal and are ready to get out and hunt again");
            plHealth=100;
        }else{
            plHealth=100;
            System.out.println("You were badly hurt, and resting allowed you to heal up, you rest for the night and feel back to full health");
        }
        System.out.println("You are now met by the mayor of the town at the inn, who informs you that the final beast is the most dangerous one you will have faced, and he wishes you luck with killing it");
        System.out.println("as it has killed numerous adventurers before, but if you kill it you will recieve the reward you desire.");
        System.out.println("You head back into the woods for one final time, experienced as you are in navigating these woods by now, you are able to go to where the hawk attacked you last time.");
        System.out.println("You look around the clearing and see nothing, so you push on into the dense brush around the clearing, eventually clearing most of it, and just as you feel you are losing hope,");
        System.out.println("you feel as if you are being watched, you look around you and don't see anything, then you look up.....and sitting in a massive nest... a gryphon!");
        System.out.println("You see it looks irritated at being discovered and you also see numerous objects entertwined in the walls of the nest that don't look like they would be found in the forest.");
        System.out.println("Either the gryphon found the objects in town or took them from traveling traders that went by the town every so often. Nevertheless the gryphon screeches at you loudly before flapping it's wings and attacking.");
        System.out.println("You brace yourself for the fight and so it begins!");
        
        while(monThree){
            System.out.println("Your Health: "+plHealth);
            System.out.println("What do you wish to do?(Fight,Heal,Dodge,Flee)");
            userChoice=input.nextLine().toLowerCase();
            if(userChoice.toLowerCase().equals("fight")){
                plAttack=random.nextInt(20)+4;
                if(plAttack==23){
                    System.out.println("Natural 20! Critical Hit!");
                    plDmg=random.nextInt(12)+1+random.nextInt(12)+1;
                   monThreeHealth-=plDmg;
                    System.out.println("The gryphon takes "+plDmg+" damage from your attack");
                }else if(plAttack<23&&plAttack>=15){
                    System.out.println("You hit the gryphon with your axe!");
                    plDmg=random.nextInt(12)+1;
                    monThreeHealth-=plDmg;
                    System.out.println("The gryphon takes "+plDmg+" damage from your attack");
                }else{
                    System.out.println("You swing wildly and miss the gryphon.");
                }
                System.out.println("The gryphon now attacks you");
                monAttack=random.nextInt(20)+6;
                if(monAttack==25){
                    System.out.println("The gryphon claws you at a critical area!");
                    monDamage=random.nextInt(10)+1+random.nextInt(10)+1;
                    System.out.println("You take "+monDamage+" points of damage.");
                    plHealth=plHealth-monDamage;
                }else if(monAttack<25&&monAttack>=17){
                    System.out.println("The gryphon manages to claw you.");
                    monDamage=random.nextInt(10)+1;
                    System.out.println("You take "+monDamage+" points of damage.");
                    plHealth=plHealth-monDamage;
                }else{
                    System.out.println("The gryphon attempts to claw you and you deflect it with your axe");
                }
            }else if(userChoice.toLowerCase().equals("heal")){
                if(takenPotion){
                    System.out.println("You already drank all of your health potions!");
                }else{
                    if(plHealth==100){
                        System.out.println("You are at maximum health so a health potion will not help you.");
                    }else if(plHealth<100&&plHealth>=60){
                        System.out.println("You drink your health potion and feel back to normal");
                        plHealth=100;
                        numPotions--;
                        if(numPotions==0){
                            takenPotion=true;
                        }
                    }else{
                        System.out.println("You drink a health potion and feel better, you have gained 40 health points back");
                        plHealth+=40;
                        numPotions--;
                        if(numPotions==0){
                            takenPotion=true;
                        }
                    }
                }
            }else if(userChoice.toLowerCase().equals("dodge")){
                System.out.println("You dodge the gryphon's attack!");
            }else if(userChoice.toLowerCase().equals("flee")){
                System.out.println("You flee from the gryphon, guess you aren't as strong as you thought");
            }else{
                System.out.println("Please give a valid input");
                userChoice=input.next();
            }
            if(monThreeHealth<=0){
                System.out.println("You successfully kill the gryphon!!!");
                monTwo=false;
            }
            if(plHealth<=0){
                System.out.println("You were killed by the gryphon, well guess the mayor is gonna have to find someone else...again");
                break;
            }
            System.out.println("You trudge back wearily back to the town, dragging the grypons corpse slowly behind you.");
            System.out.println("As you near the edge of the forest you hear people going about their day as usual...");
            System.out.println("Soon you reach the edge of the forest and you see the town once again in front of you, people milling about, then suddenly as you exit the forest a woman sees you and gasps.");
            System.out.println("Suddenly, everyone looks at her then follows her line of sight until they see you with the corpse of the gryphon behind you and also gasp in shock.'Is it dead?'a man asks to which you nod and the townsfolk cheer");
            System.out.println("You begin to drag the corpse towards the middle of town and as you do the townspeople file in behind you, celebrating the death of the beast that had terrorized them for so long. Eventually you get to the center of town where the mayor stands awaiting you as obviously someone had run ahead to inform him.");
            System.out.println("'Well well well, I honestly can't say I expected this, but it seems you have actually done it!', the mayor exclaims. You drop the corpse in the middle of the square and people gather around and look at it. You hear murmuring from the crowd in disbelief. 'I can't believe it's dead' 'You sure that's it?' 'Nobody has been able to defeat it...how did this one do it?'");
            System.out.println("All the townspeople await the mayor of the town to speak and eventually he does, 'Citizens, it seems today we have found the mightiest warrior who was able to defeat the beast that haunted our town and for that we owe them our deepest gratitude. Many adventurers have come and attempted to slay this beast but none succeeded until this mighty warrior'");
            System.out.println("The mayor goes on and on about how the town owes you so much for what you have done and finally gives you the prize they had promised, a thousand gold pieces and a deed to a large area of land where the townsfolk will build you a home or castle so that you may stay to guard them whenever the time arises that something threatens them again");
            System.out.println("The mayor then speaks up one final time,'Now that we are free to live our lives once again, we can now celebrate the warrior who conquered the beasts of the forest! Let us celebrate with a feast and dance!' and chefs immediately bring out food and drink, enough to serve the entire town and then some, you are swept up in citizens thanking you for what you did and offering you food, drinks, and toasting you for your success");
            System.out.println("The celebration lasts throughout the night and the next day, your new life begins, as the hero of the town and the new guardian, hail to you my friend, for you were succesful when no one else was and so ends your tale here");
            break;
        }

    }
}